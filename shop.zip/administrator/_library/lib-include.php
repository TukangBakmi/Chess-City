<!-- bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- JQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Sweet Alert -->
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- js -->
<script src="_library/js/uploadImage.js"></script>
<script src="_library/js/feedback.js"></script>
<script src="_library/js/logout.js"></script>

<!-- css -->
<link type="text/css" href="_library/css/uploadImage.css" rel="stylesheet"/>