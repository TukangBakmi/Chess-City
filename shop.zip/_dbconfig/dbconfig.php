<?php
    $servername = "localhost";
    $username = 'root';
    $password = '';
    $dbName = '20212_wp2_412020031';
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbName);
?>