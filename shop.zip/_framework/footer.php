<footer>
    <div class="row">
        <div class="col-5">
            <a href="https://instagram.com/chess_city?igshid=YmMyMTA2M2Y=">
                <img class="logo" src="_library/image/Logo2.png">
            </a>
            <p>Gens Una Sumus, We are One Family</p>
        </div>
        <div class="col-3">
            <p style="text-align:left;">Quick Links:</p>
            <ul>
                <li style="color: white;"><a href="./basics.php">Basics</a></li>
                <li style="color: white;"><a href="./strategies.php">Strategies</a></li>
                <li style="color: white;"><a href="./puzzles.php">Puzzles</a></li>
                <li style="color: white;"><a href="./aboutus.php">About Us</a></li>
            </ul>
        </div>
        <div class="col-4" style="text-align: right;">
            <p>Contact Us:</p>
            <a href="https://instagram.com/chess_city?igshid=YmMyMTA2M2Y=" class="fa-brands fa-instagram"> chess_city</a><br>
            <a href="https://twitter.com/chesscity2" class="fa-brands fa-twitter"> chesscity2</a><br>
            <p class="fa-regular fa-envelope"> chesscity124@gmail.com</p><br>
            <p class="fa-regular fa-envelope"> albert.412020031@civitas.ukrida.id</p>
        </div>
    </div>
    <div class="footer-bottom">
        &copy; chesscity.com | <a href="https://instagram.com/aalbeert.12?igshid=YmMyMTA2M2Y=">Designed by Albert Ardiansyah</a>
    </div>
</footer>